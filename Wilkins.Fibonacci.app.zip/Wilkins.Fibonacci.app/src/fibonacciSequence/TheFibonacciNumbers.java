package fibonacciSequence;

import javax.swing.JOptionPane;

public class TheFibonacciNumbers
{

	public TheFibonacciNumbers()
	{
		long[] calculatedFibonacciNumbers;
		String userChoice;
		String fibonacciNumbersAsList;

		while (true)
		{

			userChoice = userChoiceIdentifier();

			if (userChoice.equalsIgnoreCase("Calculate"))
			{
				calculatedFibonacciNumbers = calculateFibonacciNumbers();

				fibonacciNumbersAsList = fibonacciNumbersToList(calculatedFibonacciNumbers);

				displayFibonacciNumbers(fibonacciNumbersAsList);
			} else if (userChoice.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
			} else
			{
				invalidInputDisplay();
			}
		}
	}

	public void invalidInputDisplay()
	{
		JOptionPane.showMessageDialog(null, "The Input You Entered is Invalid, Please Enter Again");
	}

	public String userChoiceIdentifier()
	{
		String userInput;

		userInput = JOptionPane.showInputDialog(
				"Would You Like to Calculate and Display the First Fifty Fibonacci Numbers or Exit the Program, Please Enter Calculate or Exit");

		return userInput;
	}

	public long[] calculateFibonacciNumbers()
	{
		long calculatedFibonacciNumbers[] = new long[50];
		long termOne = 0;
		long termTwo = 1;
		calculatedFibonacciNumbers[0] = termOne;

		for (int count = 1; count < calculatedFibonacciNumbers.length; count++)
		{
			calculatedFibonacciNumbers[count] = termOne + termTwo;

			termOne = termTwo;

			termTwo = calculatedFibonacciNumbers[count];
		}
		return calculatedFibonacciNumbers;
	}

	public String fibonacciNumbersToList(long[] calculatedFibonacciNumbers)
	{
		String fibonacciNumbersAsList = "";

		for (int count = 0; count < calculatedFibonacciNumbers.length; count++)
			if (count != calculatedFibonacciNumbers.length - 1)
			{
				fibonacciNumbersAsList += calculatedFibonacciNumbers[count] + ", ";

				if (count % 10 == 0 && count != 0)
				{
					fibonacciNumbersAsList += "\n";
				}
			} else
			{
				fibonacciNumbersAsList += calculatedFibonacciNumbers[count];
			}
		return fibonacciNumbersAsList;

	}

	public void displayFibonacciNumbers(String fibonacciNumbersAsList)
	{
		JOptionPane.showMessageDialog(null, "The First Fifty Fibonacci Numbers are:\n " + fibonacciNumbersAsList);
	}
}
